import os
os.system("su -c 'svc power shutdown'")
